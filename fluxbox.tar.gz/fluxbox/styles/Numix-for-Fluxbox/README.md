# Numix-for-Fluxbox
A Fluxbox theme to match the Numix GTK theme

Based on the Numix GTK theme by the Numix Project (https://github.com/numixproject/numix-gtk-theme) and flux-numix theme by encomjones (https://github.com/encomjones/flux_numix).

Requires the Droid Sans fonts.

For screenshots see the screenshots folder.

# Installation

Copy the contents of this directory to $HOME/.fluxbox/styles
