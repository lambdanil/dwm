adwaita-fluxbox-theme
Author:	Boyd Kelly
Date	2016-08-07

This theme attempts to reproduce the simplicity of Adwaita as closely as possible in Fluxbox.  I have not used the pixmap window decorations, but the colors of Adwaita.  This works better on highdpi monitors.

To the the best of this theme, please use lxappearance or another utility to select the Adwaita gtk-2 and gtk-3 themes.  This will make a consistant "Gnome Look" for your applications.

Enjoy!


